# Payroll App

This repository contains two versions of the Texas Payroll program:

1. Streamlit Web App (app.py) - use in the browser
2. Command-line Script (payroll_cli.py) - run locally with Python

## Deployment (Streamlit Cloud)
1. Create a free account at https://streamlit.io/cloud
2. Upload this repo
3. Select app.py as the main file
4. Deploy!
